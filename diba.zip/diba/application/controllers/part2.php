<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class part2 extends CI_Controller {

	public function index()
	{
		$this->load->view('about_message');
	}

}

/* End of file About.php */
/* Location: ./application/controllers/About.php */