<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class part3 extends CI_Controller {

	public function index()
	{
		$this->load->view('contact_message');
	}

}

/* End of file Contact.php */
/* Location: ./application/controllers/Contact.php */