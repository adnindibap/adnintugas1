<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Case</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">FrameWork</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo site_url() ?>/part1">Home</a></li>
    <li class="active"><a href="<?php echo site_url() ?>/part2">About</a></li>
    <li><a href="<?php echo site_url() ?>/part3">Contact</a></li>
    </ul>
  </div>
</nav>
  

          <div class="jumbotron">

      <table border=0 class="table" width=90% cellpadding="0" align="CENTER">
         
         <tr>
          <td>
          <td rowspan="4" width=35% align=center>
            <img src="<?php echo base_url() ?>img/logo polinema.png" class="img-responsive" alt="Image" width=200>
          </td>
              <CENTER><h1>DATA DIRI</h1></CENTER>

          </td>
        </tr>

         <tr align="CENTER">
          <td>
            <div class="alert alert-info" role="alert"><h3>Nama : Adnin Diba Purnomo</h3></div>
          </td>
        </tr>

        <tr align="CENTER">
           <td>
            <div class="alert alert-danger" role="alert"><h3>Kelas : TI - 2C</h3></div>
          </td>
        </tr>

        <tr align="CENTER">
          <td>
            <div class="alert alert-info" role="alert"><h3>NIM : 1541180060</h3></div>
          </td>
        </tr>


        <tr align="CENTER">
          <td>
            <div class="alert alert-danger" role="alert"><h3>Alamat : Jl. Agus Salim 20</h3></div>
          </td>
        </tr>

         <tr align="CENTER">
          <td>
            <div class="alert alert-info" role="alert"><h3>No Telp : 085755055131</h3></div>
          </td>
        </tr>

        <tr align="CENTER">
          <td>
            <div class="alert alert-danger" role="alert"><h3>Hobby : Renang</h3></div>
          </td>
        </tr>




      </table>    
      </div>

</body>
</html>


