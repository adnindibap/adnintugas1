<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Case</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">FrameWork</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo site_url() ?>/part1">Home</a></li>
      <li class="active"><a href="<?php echo site_url() ?>/part2">About</a></li>
      <li><a href="<?php echo site_url() ?>/part3">Contact</a></li>
    </ul>
  </div>
</nav>
        <div class="jumbotron">
      <form>
      <table class="" border=0 width="700" cellpadding="0" cellspacing="0" align="center">
        <tr>
          <td rowspan="4" width=35% align=center>
            <img src="<?php echo base_url() ?>img/logo polinema.png" class="img-responsive" alt="Image" width=200>
          </td>
          <td>
            <div class="input-group">
            <span class="input-group-addon" id="sizing-addon2">Nama</span>
            <input type="text" class="form-control" placeholder="Masukkan Nama" aria-describedby="sizing-addon2">
        </div>
          </td>
        </tr>
        <tr>
          <td>
            <div class="input-group">
            <span class="input-group-addon" id="sizing-addon2"> E-mail </span>
            <input type="text" class="form-control" placeholder="Masukkan E-mail" aria-describedby="sizing-addon2">
        </div>
          </td>
        </tr>
        <tr>
          <td>
            <div class="input-group">
              <span class="input-group-addon" id="sizing-addon2">Pesan</span>
              <input type="text" class="form-control" placeholder="Masukkan Pesan" aria-describedby="sizing-addon2">
        </div>
          </td>
        </tr>
        <tr>
          <td>
            <input type="submit" value="SUBMIT" name="login" />
          </td>
        </tr>
      </table>
      <form>
      </div>

</body>
</html>


