<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Case</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">FrameWork</a>
    </div>
    <ul class="nav navbar-nav">
      	<li><a href="<?php echo site_url() ?>/part1">Home</a></li>
		<li class="active"><a href="<?php echo site_url() ?>/part2">About</a></li>
		<li><a href="<?php echo site_url() ?>/part3">Contact</a></li>
    </ul>
  </div>
</nav>
  

			<div class="jumbotron">
					<div class="container">
						<h1>Assalamualaikum Wr. Wb.</h1>
						<h2>Selamat Datang dan Terimakasih <br>Sudah Berkunjung di Website bebasis Framework Kami</h2>
						<p>Contents ...</p>
						<p>
							<a class="btn btn-primary btn-lg">Learn more</a>
						</p>
					</div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
					Alhadulilllah, puji serta syukur senantiasa selalu hanya kepada Allah SWT, karena atas segala rahmat dan hidayahnya, bisa memberikan kontribusi bagi para pengunjung, sehingga dapat dengan mudah memperoleh informasi penting terkait dengan mudah dan akurat, baik menyangkut dari profil program studi penndidikan matematika, mata kuliah, tenaga pengajar, data mahasiswa, kegiatan mahasiswa, hingga penelitian yang pernah diselenggarakan oleh program studi.
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
					Mahasiswa Teknik Informatika terus dituntut untuk memantapkan ilmu pengetahuannya seiring perkembangan zaman, tuntutan ini mengacu kepada proses peningkatan kualitas yang bermutu, daya saing yang ketat, dan meningkatkan prestasi pada tingkat nasioanal maupun internasional
				</div>

</body>
</html>


